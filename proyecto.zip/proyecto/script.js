const storyElement = document.getElementById('story');
const nextButton = document.getElementById('next-btn');
let currentScene = 0;

const scenes = [
  "Te encuentras en una oscura cueva. A la izquierda, ves una puerta. A la derecha, un pasaje estrecho.",
  "Al entrar en la puerta, encuentras un tesoro brillante. Â¿Lo tomas o sigues explorando?",
  "Decides seguir explorando y te encuentras con un dragÃ³n. Â¿Luchas o corres?",
  "Lamentablemente, el dragÃ³n te atrapa. Â¡Fin del juego!",
  "Â¡Felicidades! Has tomado el tesoro y has completado la aventura."
];

function next() {
  currentScene++;
  if (currentScene < scenes.length) {
    storyElement.textContent = scenes[currentScene];
  } else {
    storyElement.textContent = "Â¡Fin del juego!";
    nextButton.disabled = true;
  }
}